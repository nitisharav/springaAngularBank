import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-faqmain',
  templateUrl: './faqmain.component.html',
  styleUrls: ['./faqmain.component.css']
})
export class FaqmainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
