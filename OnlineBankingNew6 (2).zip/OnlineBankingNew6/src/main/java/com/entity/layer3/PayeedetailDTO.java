package com.entity.layer3;

public class PayeedetailDTO {

	private String uaccno;
//	public PayeedetailDTO() {
	//	super();
		// TODO Auto-generated constructor stub
//	}
	private String paccno;
	
	private String pname;
	
	
	public String getUaccno() {
		return uaccno;
	}
	public void setUaccno(String uaccno) {
		this.uaccno = uaccno;
	}
	public String getPaccno() {
		return paccno;
	}
	public void setPaccno(String paccno) {
		this.paccno = paccno;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	
}