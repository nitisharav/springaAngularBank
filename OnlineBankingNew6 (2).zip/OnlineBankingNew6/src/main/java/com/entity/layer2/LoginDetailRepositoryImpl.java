package com.entity.layer2;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.layer1.Logindetail;
import com.entity.layer1.Userdetail;



@Repository
public class LoginDetailRepositoryImpl implements LoginDetailRepository {

	@PersistenceContext
	private EntityManager em;
	
	/*@Override
	@Transactional
public void save(Logindetail user) {
		 //TODO Auto-generated method stub
		em.persist(user);
	}
	*/
	//@Override
		@Transactional
		public List<Logindetail> getAl1l() {
			Query query= em.createNativeQuery("select * from  LoginDetails", Logindetail.class);
			
			 List<Logindetail> user= query.getResultList();
			return user;
			
		}

	

	/*@Transactional
    public String getUserId() {
		// TODO Auto-generated method stub
		Query q=em.createNativeQuery("select max(u.Userid) from Logindetails u", Logindetail.class);
				System.out.println(q.getSingleResult());
		return(String)q.getSingleResult();
				
	}
*/
	@Transactional
    public String getUserId() {
		// TODO Auto-generated method stub
		return (String) em.createNativeQuery("select max(u.Userid) from Logindetails u").getSingleResult();
		//		System.out.println(q.getSingleResult());
	//	return(String)q.getSingleResult();
				
	}
//	@Override
//	public void save(Logindetail login) {
//		// TODO Auto-generated method stub
		
//	}
	//@Transactional
//	public List<Logindetail> getUserByAccNumber(String accNumber)
	// {
		
	//	Query query= em.createNativeQuery("select * from Logindetails u where u.ACCOUNTNUMBER.accountno="+accNumber,Logindetail.class);
				
		
				
		//			List<Logindetail> items = query.getResultList(); 

					
			//		return items;
	//	}

	
	//@Transactional
	//public void resetPassword(String updatedPassword,String accountno) {
	
		
		
		
	//	Query query = em.createNativeQuery("update Logindetails set Login_Password ='"+updatedPassword+"' where ACCOUNTNUMBER ="+accountno,Logindetail.class);
	//	query.executeUpdate();
		
	//}
	


@Transactional
public void resetTransactionPassword(String userId,String updatedPassword) {

	System.out.println("3");
	
	
	Query query = em.createNativeQuery("update Logindetails set Transaction_Password ='"+updatedPassword+"' where USERID ='"+userId+"'",Logindetail.class);
	query.executeUpdate();
	
}


			

/*@Override
@Transactional
public String getUserByAccNumber(String accNumber) {
	// TODO Auto-generated method stub
	return (String)em.createNamedQuery("getIdByAccNumber")
			.setParameter("accNumber",accNumber).getSingleResult();
}
@Override
@Transactional
public String getTransactionPassword(String fromAccNumber) {
	// TODO Auto-generated method stub
	System.out.println(fromAccNumber);
	return (String)em.createNamedQuery("getTnPassword")
			.setParameter("accNumber",fromAccNumber).getSingleResult();
}
}
	
	@Override
	@Transactional
	public OpenAccount findbyId(String accNumber) {
		return em.find(OpenAccount.class,accNumber);
	}
	
	@Override
	@Transactional
	public boolean isAccountRegistered(String accNumber) {
		return (Long)em.createNamedQuery("getAcc").setParameter("accNumber", accNumber)
				.getSingleResult()==1 ? true : false;
	}
	
	@Override
	@Transactional
	public boolean validUserIdPassword(String userId, String password) {
		// TODO Auto-generated method stub
		return (Long) em.createNamedQuery("loginCheck").setParameter("id", userId).setParameter("password", password)
				.getSingleResult()==1?true:false;
	}

	@Override
	@Transactional
	public User findUserById(String userId) {	
		return em.find(User.class,userId);
	}

	@Override
	@Transactional
	public boolean isUserValid(String userId) {
		return (Long) em.createNamedQuery("userIdCheck").setParameter("id",userId)
				.getSingleResult()==1?true:false;
	}

	@Override
	@Transactional
	public int getNoOfInvalidAttempts(String userId) {
		// TODO Auto-generated method stub
		return (Integer)em.createNamedQuery("getInvalidAttempts").setParameter("id", userId)
				.getSingleResult();
	}

	@Override
	@Transactional
	public void setNoOfInvalidAttempts(String userId, int attempts) {
		// TODO Auto-generated method stub
		em.createNamedQuery("updateInvalidAttempts")
		.setParameter("attempts",attempts)
		.setParameter("id", userId)
		.executeUpdate();
	}
	
	@Override
	@Transactional
	public void resetPassword(String userId, String updatedPassword) {
		em.createNamedQuery("changePassword")
		.setParameter("id",userId)
		.setParameter("password",updatedPassword)
		.executeUpdate();
	}
	@Override
	@Transactional
	public String getUserByAccNumber(String accNumber) {
		// TODO Auto-generated method stub
		return (String)em.createNamedQuery("getIdByAccNumber")
				.setParameter("accNumber",accNumber).getSingleResult();
	}
	@Override
	@Transactional
	public String getTransactionPassword(String fromAccNumber) {
		// TODO Auto-generated method stub
		System.out.println(fromAccNumber);
		return (String)em.createNamedQuery("getTnPassword")
				.setParameter("accNumber",fromAccNumber).getSingleResult();
	}
	@Override
	@Transactional
	public void savelastLogin(String userId,String date) {
		// TODO Auto-generated method stub
		em.createNamedQuery("setLastLoginDate")
		.setParameter("id",userId)
		.setParameter("dateTime",date)
		.executeUpdate();
	}

	@Override
	@Transactional
	public void resetTransactionPassword(String userId, String updatedPassword) {
		System.out.println(userId);
		System.out.println(updatedPassword);
		em.createNamedQuery("changeTransactionPassword")
		.setParameter("id",userId)
		.setParameter("password",updatedPassword)
		.executeUpdate();
	}
}*/
	

	
	@Transactional
	public void save(Logindetail user) {
	System.out.println("registering....");	
		em.persist(user);
		
	}

	@Transactional 
	public boolean isUserPresent() 
	{
		System.out.println("3.1");
    Query q = em.createNativeQuery("select count(*) from Logindetails");
    BigDecimal a = (BigDecimal)q.getSingleResult();
    if(a==(BigDecimal.ZERO))
    
        return false ;
    else
    	return true;   
	} 
//	@Override
//	public String getUserId() {
		// TODO Auto-generated method stub
//		return null;
//	}

/*	@Override
	public Userdetail findbyId(String id) {
		// TODO Auto-generated method stub
		return null;
	}
*/
	   @Transactional	    	       
	    public boolean isAccountRegistered(String accNumber) 
	    {
		   System.out.println("7");
	        Query q = em.createNativeQuery("select count(*) from Logindetails where accountnumber='"+accNumber+"'");
	        BigDecimal a = (BigDecimal)q.getSingleResult();
	        if(a==(BigDecimal.ZERO))
	            return false;
	        else
	            return true;
	    }
	    

	@Transactional
	 @Override
	    public boolean validUserIdPassword(String userId, String password) {
		System.out.println("8");
	    Query q = em.createNativeQuery("Select count(userid) from logindetails where userid='"+userId+"'and login_password='"+password+"'");
	    BigDecimal a = (BigDecimal)q.getSingleResult();
	    if(a==(BigDecimal.ZERO))
	        return false;
	    else
	        return true;
	    }
	@Transactional
	public Logindetail findUserById(String userId) {
		System.out.println("9");
		return em.find(Logindetail.class,userId);
	}

	@Transactional
	public Userdetail findbyId(String accountno) {
		System.out.println("6");
		 return em.find(Userdetail.class,accountno);
		}
		

	@Transactional
	 @Override
	    public boolean isUserValid(String userId) {
		System.out.println("10");
	        Query q = em.createNativeQuery("select count(*) from logindetails where userid='"+userId+"'");
	        BigDecimal a = (BigDecimal)q.getSingleResult();
	        if(a==(BigDecimal.ZERO))
	            return false;
	        else
	            return true;
	    }

	@Transactional
	public int getNoOfInvalidAttempts(String userId) {
		System.out.println("11");
		 String query = "select numberofinvalidattempts from Logindetail where userid=:x";
	        Query  q = (Query) this.em.createQuery(query);
	        q.setParameter("x", userId);
	        int r= (int) q.getSingleResult();
	        return r;
	}
	@Transactional
	public void setNoOfInvalidAttempts(String userId, int attempts)
	{
		System.out.println("12");
	Query q=em.createNativeQuery("update logindetails set NUMBEROFINVALIDATTEMPTS="+attempts+" where USERID='"+userId+"'");
	q.executeUpdate();
	}
	

//	@Override
//	public void resetPassword(String userId, String updatedPassword) {
//		// TODO Auto-generated method stub
		
//	}

//	@Override
//	public String getUserByAccNumber(String accNumber) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Override
	public String getTransactionPassword(String fromAccNumber) {
		System.out.println("14");
		// TODO Auto-generated method stub
		return null;
	}

	@Transactional
	public void savelastLogin(String userId, String date) {
		System.out.println("15");
		Query query = em.createNativeQuery("update Logindetails set LASTLOGIN ='"+date+"' where USERID ='"+userId+"'",Logindetail.class);
		query.executeUpdate();
		
	}

//	@Override
//	public void resetTransactionPassword(String userId, String updatedPassword) {
//		// TODO Auto-generated method stub
		
//	}
/*	@Transactional
	public void resetTransactionPassword(String userId,String updatedPassword) {

		
		
		
		Query query = em.createNativeQuery("update Logindetails set Transaction_Password ='"+updatedPassword+"' where USERID ='"+userId+"'",Logindetail.class);
		query.executeUpdate();
		
	}

	*/

/*	@Transactional
	public void resetPassword(String updatedPassword,String accountno) {

	Query query = em.createNativeQuery("update Logindetails set Login_Password ='"+updatedPassword+"' where accountnumber ="+accountno,Logindetail.class);
	query.executeUpdate();

	}
	
	*/

@Transactional
public void resetPassword(String userid,String updatedpassword) {
	System.out.println("2");
Query query = em.createNativeQuery("update Logindetails set Login_Password ='"+updatedpassword+"' where userid ='"+userid+"'",Logindetail.class);
query.executeUpdate();

}

	
	
/*	@Transactional
	public List<Logindetail> getUserId(){
		Query q = em.createNativeQuery("select * from logindetails", Logindetail.class);
		List<Logindetail> f = q.getResultList();
		return f;
	}
*/
//@Override
//	public List<Logindetail> getAll() {
		// TODO Auto-generated method stub
//		return null;
//	}
/*
@Override
public String getUserId() {
System.out.println("5");
	// TODO Auto-generated method stub
	return null;
}
*/

//@Override
//public List<Logindetail> getUserId() {
//	// TODO Auto-generated method stub
//	return null;
//}




//@Override
//public List<Logindetail> getAll1() {
//	// TODO Auto-generated method stub
//	return null;
//}
	

	
	
/*	@Transactional
	public List<Logindetail> getUserByAccNumber(String accno ) {
		
		Query query= em.createNativeQuery("select * from logindetails where logindetails.accountnumber="+accno,
		
				Logindetail.class);
	//	select u.userId from User u where u.accountNumber.accountNumber =:accNumber

				 List<Logindetail> items = query.getResultList(); 
				return items;

}*/
	
	@Transactional
	public String getUserByAccNumber(String accNumber)
	 {
		System.out.println("13");
		//Query query= em.createNativeQuery("select userid from Logindetails  where accountnumber='"+accNumber+"'",Logindetail.class);
	    //String query = "select userid from Logindetail where accountno=:x";
	    String query = "select userid from Logindetail where userdetail2.accountno=:x";
        Query  q = (Query) this.em.createQuery(query);
        q.setParameter("x", accNumber);
        String r= (String) q.getSingleResult();
        return r;	
		
				
					//String items = (String) query.getSingleResult();

					
				//	return items;
		}

	/*
		@Transactional
	public Logindetail getUserByAccNumber(Userdetail a) {
			//Query q = null;
			String query = "from Logindetail where userdetail2 =:x";
	   Query     q = (Query) this.entityManager.createQuery(query);
	        q.setParameter("x", a);
	        Logindetail cs = (Logindetail)q.getSingleResult();
	       // System.out.println(cs.getLastlogin());
	          
		return cs;
	
	}*/
		@Transactional
	    public List<Logindetail> getAll() {
			System.out.println("15");
	        String s="from Logindetail";
	        Query query = em.createQuery(s);
	        List<Logindetail> logindetail=query.getResultList();
	        return logindetail;
		}
	/*public Logindetail get(String accountno)
	{
		 
			   
		       
		        Logindetail re = entityManager.find(Logindetail.class, accountno);
				return re;
	}
	
		@Override
		public Logindetail get(String accountno) {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public Logindetail getUserByAccNumber(String accountno) {
			// TODO Auto-generated method stub
			return null;
		}
}*/



/*		@Override
		public List<Logindetail> getUserByAccNumber1(String accno) {
			// TODO Auto-generated method stub
			return null;
		}
*/

/*
		@Override
		public String getUserByAccNumber(String accNumber) {
			// TODO Auto-generated method stub
			return null;
		}

*/

	/*	@Override
		public boolean isUserPresent() {
			// TODO Auto-generated method stub
			System.out.println("4");
			return false;
		}
*/


/*		@Override
		public String getUserId() {
			// TODO Auto-generated method stub
			return null;
		}

*/

		@Override
		public List<Logindetail> getAll1() {
			System.out.println("16");
			// TODO Auto-generated method stub
			return null;
		}
}

